//==================================================
// Creator:	Peter Chan
// PCEngine
//==================================================
#pragma once

#include "Common.h"

#include "App.h"

namespace PCEngine {

App& MainApp();

} // namespace PCEngine