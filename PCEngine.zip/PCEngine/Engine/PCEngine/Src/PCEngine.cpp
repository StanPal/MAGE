#include "Precompiled.h"
#include "PCEngine.h"

namespace
{
	PCEngine::App sApp;
}

PCEngine::App& PCEngine::MainApp()
{
	return sApp;
}
