#pragma once

#include <PCEngine/Inc/PCEngine.h>

class GameState : public PCEngine::AppState
{
public:
	void Initialize() override;
	void Terminate() override;

	void Update(float deltaTime) override;
	void Render() override;
	void DebugUI() override;

private:
	PCEngine::Graphics::Camera mCamera;

	PCEngine::Graphics::Mesh mMesh;
	PCEngine::Graphics::MeshBuffer mMeshBuffer;

	struct TransformData
	{
		PCEngine::Math::Matrix4 world;
		PCEngine::Math::Matrix4 wvp;
		PCEngine::Math::Vector3 viewPosition;
		float padding;
	};
	struct SettingsData
	{
		float specularMapWeight = 1.0f;
		float bumpMapWeight = 1.0f;
		float normalMapWeight = 1.0f;
		float padding;
	};

	using TransformBuffer = PCEngine::Graphics::TypedConstantBuffer<TransformData>;
	using LightBuffer = PCEngine::Graphics::TypedConstantBuffer<PCEngine::Graphics::DirectionalLight>;
	using MaterialBuffer = PCEngine::Graphics::TypedConstantBuffer<PCEngine::Graphics::Material>;
	using SettingsBuffer = PCEngine::Graphics::TypedConstantBuffer<SettingsData>;

	TransformBuffer mTransformBuffer;
	LightBuffer mLightBuffer;
	MaterialBuffer mMaterialBuffer;
	SettingsBuffer mSettingsBuffer;

	PCEngine::Graphics::DirectionalLight mDirectionalLight;
	PCEngine::Graphics::Material mMaterial;

	PCEngine::Graphics::VertexShader mEarthVertexShader;
	PCEngine::Graphics::PixelShader mEarthPixelShader;
	PCEngine::Graphics::VertexShader mCloudVertexShader;
	PCEngine::Graphics::PixelShader mCloudPixelShader;

	PCEngine::Graphics::Sampler mSampler;
	PCEngine::Graphics::Texture mDiffuseMap;
	PCEngine::Graphics::Texture mSpecularMap;
	PCEngine::Graphics::Texture mDisplacementMap;
	PCEngine::Graphics::Texture mNormalMap;
	PCEngine::Graphics::Texture mNightLightMap;
	PCEngine::Graphics::Texture mCloudMap;

	PCEngine::Graphics::BlendState mBlendState;

	PCEngine::Math::Vector3 mRotation = 0.0f;
	float mCloudRotation = 0.0f;

	SettingsData mSettings;
};