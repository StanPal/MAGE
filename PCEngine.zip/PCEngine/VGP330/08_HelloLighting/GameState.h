#pragma once

#include <PCEngine/Inc/PCEngine.h>

class GameState : public PCEngine::AppState
{
public:
	void Initialize() override;
	void Terminate() override;

	void Update(float deltaTime) override;
	void Render() override;
	void DebugUI() override;

private:
	PCEngine::Graphics::Camera mCamera;

	PCEngine::Graphics::MeshPN mMesh;
	PCEngine::Graphics::MeshBuffer mMeshBuffer;

	struct TransformData
	{
		PCEngine::Math::Matrix4 world;
		PCEngine::Math::Matrix4 wvp;
		PCEngine::Math::Vector3 viewPosition;
		float padding;
	};

	using TransformBuffer = PCEngine::Graphics::TypedConstantBuffer<TransformData>;
	using LightBuffer = PCEngine::Graphics::TypedConstantBuffer<PCEngine::Graphics::DirectionalLight>;
	using MaterialBuffer = PCEngine::Graphics::TypedConstantBuffer<PCEngine::Graphics::Material>;

	TransformBuffer mTransformBuffer;
	LightBuffer mLightBuffer;
	MaterialBuffer mMaterialBuffer;

	PCEngine::Graphics::DirectionalLight mDirectionalLight;
	PCEngine::Graphics::Material mMaterial;

	PCEngine::Graphics::VertexShader mGouraudShadingVertexShader;
	PCEngine::Graphics::PixelShader mGouraudShadingPixelShader;

	PCEngine::Graphics::VertexShader mPhongShadingVertexShader;
	PCEngine::Graphics::PixelShader mPhongShadingPixelShader;

	PCEngine::Math::Vector3 mRotation = 0.0f;
};