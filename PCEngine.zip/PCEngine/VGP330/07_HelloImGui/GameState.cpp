#include "GameState.h"

#include <ImGui/Inc/imgui.h>

using namespace PCEngine::Graphics;
using namespace PCEngine::Input;
using namespace PCEngine::Math;

void GameState::Initialize()
{
	GraphicsSystem::Get()->SetClearColor(Colors::LightGray);

	mCamera.SetPosition({ 0.0f, 0.0f, -5.0f });
	mCamera.SetDirection({ 0.0f, 0.0f, 1.0f });

	// Final Homework:
	// - Update HelloTexturing to use a MeshPX data to draw texture mapped cubes
	// - You will need to add Sampler and Texture classes provided
	// - You will need to use DoTexturing.fx shaders
	// - Add a new class called Graphics::MeshBuilder with the following functions
	//
	//	namespace PCEngine::Graphics
	//	{
	//		class MeshBuilder
	//		{
	//		public:
	//			static MeshPX CreatePlanePX();
	//			static MeshPX CreateCylinderPX();
	//			static MeshPX CreateSpherePX(float radius, int rings = 16, int slices = 16);
	//		};
	//	}
	//
	// - This will allow you to create a mesh easily by doing:
	//
	//		auto mesh = MeshBuilder::CreateSpherePX(...);
	//
	// - Add HelloEarth to test a texture mapped sphere using Earth texture

	// A plane:
	// for (int y = 0; y < height; ++y)
	//  for (int x = 0; x < width; ++x)
	//		vertices.push_back({x, y, 0.0f}...);

	// A cylinder:
	// for (int y = 0; y < height; ++y)
	//  for (int theta = 0; theta < TwoPi; theta += ..)
	//		vertices.push_back({sin(theta), y, cos(theta)}...);

	// A sphere:
	// for (int phi = 0; phi < Pi; phi += ...)
	//  for (int theta = 0; theta < TwoPi; theta += ..)
	//		vertices.push_back({sin(theta) * r, y, cos(theta) * r}...);

	// Front
	mMesh.vertices.emplace_back(VertexPX{ Vector3{ -0.5f, -0.5f, -0.5f }, { 0.0f, 1.0f } });
	mMesh.vertices.emplace_back(VertexPX{ Vector3{ -0.5f,  0.5f, -0.5f }, { 0.0f, 0.0f } });
	mMesh.vertices.emplace_back(VertexPX{ Vector3{  0.5f,  0.5f, -0.5f }, { 1.0f, 0.0f } });
	mMesh.vertices.emplace_back(VertexPX{ Vector3{  0.5f, -0.5f, -0.5f }, { 1.0f, 1.0f } });

	mMesh.vertices.emplace_back(VertexPX{ Vector3{ -0.5f, -0.5f,  0.5f }, { 0.0f, 0.0f } });
	mMesh.vertices.emplace_back(VertexPX{ Vector3{ -0.5f,  0.5f,  0.5f }, { 0.0f, 0.0f } });
	mMesh.vertices.emplace_back(VertexPX{ Vector3{  0.5f,  0.5f,  0.5f }, { 0.0f, 0.0f } });
	mMesh.vertices.emplace_back(VertexPX{ Vector3{  0.5f, -0.5f,  0.5f }, { 0.0f, 0.0f } });

	// Front
	mMesh.indices.push_back(0);
	mMesh.indices.push_back(1);
	mMesh.indices.push_back(2);

	mMesh.indices.push_back(0);
	mMesh.indices.push_back(2);
	mMesh.indices.push_back(3);

	// Right
	mMesh.indices.push_back(3);
	mMesh.indices.push_back(2);
	mMesh.indices.push_back(6);

	mMesh.indices.push_back(3);
	mMesh.indices.push_back(6);
	mMesh.indices.push_back(7);

	// Back
	mMesh.indices.push_back(7);
	mMesh.indices.push_back(6);
	mMesh.indices.push_back(5);

	mMesh.indices.push_back(7);
	mMesh.indices.push_back(5);
	mMesh.indices.push_back(4);

	// Left
	mMesh.indices.push_back(4);
	mMesh.indices.push_back(5);
	mMesh.indices.push_back(1);

	mMesh.indices.push_back(4);
	mMesh.indices.push_back(1);
	mMesh.indices.push_back(0);

	// Top
	mMesh.indices.push_back(1);
	mMesh.indices.push_back(5);
	mMesh.indices.push_back(6);

	mMesh.indices.push_back(1);
	mMesh.indices.push_back(6);
	mMesh.indices.push_back(2);

	// Bottom
	mMesh.indices.push_back(4);
	mMesh.indices.push_back(0);
	mMesh.indices.push_back(3);

	mMesh.indices.push_back(4);
	mMesh.indices.push_back(3);
	mMesh.indices.push_back(7);

	mMeshBuffer.Initialize(mMesh);

	mConstantBuffer.Initialize(sizeof(Matrix4));

	mVertexShader.Initialize("../../Assets/Shaders/DoTexturing.fx", VertexPX::Format);
	mPixelShader.Initialize("../../Assets/Shaders/DoTexturing.fx");

	mSampler.Initialize(Sampler::Filter::Anisotropic, Sampler::AddressMode::Wrap);
	mTexture.Initialize("../../Assets/Images/sponge_bob.png");
}

void GameState::Terminate()
{
	mTexture.Terminate();
	mSampler.Terminate();
	mPixelShader.Terminate();
	mVertexShader.Terminate();
	mConstantBuffer.Terminate();
	mMeshBuffer.Terminate();
}

void GameState::Update(float deltaTime)
{
	const float kMoveSpeed = 10.0f;
	const float kTurnSpeed = 1.0f;

	auto inputSystem = InputSystem::Get();
	if (inputSystem->IsKeyDown(KeyCode::W))
		mCamera.Walk(kMoveSpeed * deltaTime);
	if (inputSystem->IsKeyDown(KeyCode::S))
		mCamera.Walk(-kMoveSpeed * deltaTime);
	if (inputSystem->IsMouseDown(MouseButton::RBUTTON))
	{
		mCamera.Yaw(inputSystem->GetMouseMoveX() * kTurnSpeed * deltaTime);
		mCamera.Pitch(inputSystem->GetMouseMoveY() * kTurnSpeed * deltaTime);
	}

	if (inputSystem->IsKeyDown(KeyCode::UP))
		mRotation.x += deltaTime;
	if (inputSystem->IsKeyDown(KeyCode::DOWN))
		mRotation.x -= deltaTime;
	if (inputSystem->IsKeyDown(KeyCode::LEFT))
		mRotation.y += deltaTime;
	if (inputSystem->IsKeyDown(KeyCode::RIGHT))
		mRotation.y -= deltaTime;
}

void GameState::Render()
{
	auto context = GraphicsSystem::Get()->GetContext();

	auto matRot = Matrix4::RotationX(mRotation.x) * Matrix4::RotationY(mRotation.y);
	auto matView = mCamera.GetViewMatrix();
	auto matProj = mCamera.GetPerspectiveMatrix();
	mConstantBuffer.BindVS();

	mVertexShader.Bind();
	mPixelShader.Bind();

	mSampler.BindVS();
	mSampler.BindPS();
	mTexture.BindPS();

	const float spacing = 1.8f;
	for (int y = -1; y <= 1; ++y)
	{
		for (float x = -1; x <= 1; ++x)
		{
			if (y == 0 && x == 0)
				continue;

			auto matTrans = Matrix4::Translation({ x * spacing, y * spacing, 0.0f });
			auto matWVP = Transpose(matTrans * matRot * matView * matProj);
			mConstantBuffer.Update(&matWVP);
			mMeshBuffer.Draw();
		}
	}

	SimpleDraw::AddLine(Vector3::Zero, Vector3::XAxis, Colors::Red);
	SimpleDraw::AddLine(Vector3::Zero, Vector3::YAxis, Colors::Green);
	SimpleDraw::AddLine(Vector3::Zero, Vector3::ZAxis, Colors::Blue);
	SimpleDraw::Render(mCamera);
}

void GameState::DebugUI()
{
	ImGui::ShowDemoWindow();
}