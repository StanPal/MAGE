#pragma once

#include <PCEngine/Inc/PCEngine.h>

class GameState : public PCEngine::AppState
{
public:
	void Initialize() override;
	void Terminate() override;

	void Update(float deltaTime) override;
	void Render() override;
	void DebugUI() override;

private:
	PCEngine::Graphics::Camera mCamera;

	PCEngine::Graphics::MeshPX mMesh;
	PCEngine::Graphics::MeshBuffer mMeshBuffer;

	PCEngine::Graphics::ConstantBuffer mConstantBuffer;

	PCEngine::Graphics::VertexShader mVertexShader;
	PCEngine::Graphics::PixelShader mPixelShader;

	PCEngine::Graphics::Sampler mSampler;
	PCEngine::Graphics::Texture mTexture;

	PCEngine::Math::Vector3 mRotation = 0.0f;
};