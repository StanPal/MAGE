#pragma once

#include "Common.h"

#include "Debug.h"
#include "Window.h"
#include "WindowMessageHandler.h"