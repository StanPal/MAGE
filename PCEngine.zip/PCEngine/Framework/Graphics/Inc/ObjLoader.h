#pragma once

#include "Mesh.h"

namespace PCEngine::Graphics
{
	class ObjLoader
	{
	public:
		static Mesh Load(const std::filesystem::path& filePath, float scale);
	};
}