#pragma once

#include "Mesh.h"

namespace PCEngine::Graphics
{
	class MeshBuilder
	{
	public:
		static MeshPC CreateCubePC();
		static MeshPC CreateCylinderPC();
		
		static MeshPX CreateCylinderPX();
		
		static MeshPN CreateCylinderPN();
		static MeshPN CreateSpherePN(int rings = 8, int slices = 16);
		
		static MeshPX CreateSpherePX(float radius, int rings = 16, int slices = 16);
		static Mesh CreateSphere(int rings = 16, int slices = 16);
		static Mesh CreatePlane(float size, int rows = 16, int columns = 16);
		
		static MeshPX CreateNDCQuad();
	};
}