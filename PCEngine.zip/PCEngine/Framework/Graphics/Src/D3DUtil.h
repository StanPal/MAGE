#pragma once

namespace PCEngine::Graphics {

ID3D11Device* GetDevice();
ID3D11DeviceContext* GetContext();

} // namespace PCEngine::Graphics
