#include "Precompiled.h"
#include "MeshBuilder.h"

using namespace PCEngine::Graphics;

MeshPC MeshBuilder::CreateCubePC()
{
	constexpr VertexPC vertices[] =
	{
		{ { -1.0f, -1.0f, -1.0f }, Colors::AliceBlue },
		{ { -1.0f, +1.0f, -1.0f }, Colors::Beige },
		{ { +1.0f, +1.0f, -1.0f }, Colors::BlueViolet },
		{ { +1.0f, -1.0f, -1.0f }, Colors::DeepSkyBlue },
		{ { -1.0f, -1.0f, +1.0f }, Colors::Honeydew },
		{ { -1.0f, +1.0f, +1.0f }, Colors::Indigo },
		{ { +1.0f, +1.0f, +1.0f }, Colors::LemonChiffon },
		{ { +1.0f, -1.0f, +1.0f }, Colors::OrangeRed },
	};

	constexpr uint32_t indices[] =
	{
		0, 1, 2, 0, 2, 3,
		3, 2, 6, 3, 6, 7,
		7, 6, 5, 7, 5, 4,
		4, 5, 1, 4, 1, 0,
		1, 5, 6, 1, 6, 2,
		4, 0, 3, 4, 3, 7
	};

	MeshPC mesh;
	mesh.vertices.insert(mesh.vertices.end(), std::begin(vertices), std::end(vertices));
	mesh.indices.insert(mesh.indices.end(), std::begin(indices), std::end(indices));
	return mesh;
}

MeshPC MeshBuilder::CreateCylinderPC()
{
	MeshPC mesh;

	constexpr int rings = 3;
	constexpr int slices = 16;
	constexpr float radius = 1.0f;
	constexpr float height = 3.0f;
	constexpr float heightStep = height / (rings - 1);
	constexpr float angleStep = Math::Constants::TwoPi / slices;

	for (int j = 0; j <= slices; ++j)
	{
		mesh.vertices.emplace_back(VertexPC{ { 0.0f, (height * -0.5f), 0.0f }, Colors::RosyBrown });
	}
	for (int i = 0; i < rings; ++i)
	{
		for (int j = 0; j <= slices; ++j)
		{
			float angle = angleStep * j;
			float x = cosf(angle) * radius;
			float z = sinf(angle) * radius;
			float y = (height * -0.5f) + (heightStep * i);
			mesh.vertices.emplace_back(VertexPC{ { x, y, z }, Colors::Coral });
		}
	}
	for (int j = 0; j <= slices; ++j)
	{
		mesh.vertices.emplace_back(VertexPC{ { 0.0f, (height * 0.5f), 0.0f }, Colors::RosyBrown });
	}
	for (int i = 0; i + 1 < rings + 2; ++i)
	{
		for (int j = 0; j < slices; ++j)
		{
			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 0) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));

			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 0) * (slices + 1)));
		}
	}
	return mesh;
}

MeshPX MeshBuilder::CreateCylinderPX()
{
	MeshPX mesh;

	constexpr int rings = 3;
	constexpr int slices = 16;
	constexpr float radius = 1.0f;
	constexpr float height = 3.0f;
	constexpr float heightStep = height / (rings - 1);
	constexpr float angleStep = Math::Constants::TwoPi / slices;
	constexpr float uStep = 1.0f / slices;
	constexpr float vStep = 1.0f / (rings - 1);

	for (int j = 0; j <= slices; ++j)
	{
		mesh.vertices.emplace_back(VertexPX{ { 0.0f, (height * -0.5f), 0.0f }, {j * uStep, 0.0f} });
	}
	for (int i = 0; i < rings; ++i)
	{
		for (int j = 0; j <= slices; ++j)
		{
			float angle = angleStep * j;
			float x = cosf(angle) * radius;
			float z = sinf(angle) * radius;
			float y = (height * -0.5f) + (heightStep * i);
			mesh.vertices.emplace_back(VertexPX{ { x, y, z }, {j * uStep, 1.0f - i * vStep} });
		}
	}
	for (int j = 0; j <= slices; ++j)
	{
		mesh.vertices.emplace_back(VertexPX{ { 0.0f, (height * 0.5f), 0.0f }, {j * uStep, 1.0f} });
	}
	for (int i = 0; i + 1 < rings + 2; ++i)
	{
		for (int j = 0; j < slices; ++j)
		{
			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 0) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));

			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 0) * (slices + 1)));
		}
	}
	return mesh;
}

MeshPN MeshBuilder::CreateCylinderPN()
{
	MeshPN mesh;

	constexpr int rings = 3;
	constexpr int slices = 16;
	constexpr float radius = 1.0f;
	constexpr float height = 3.0f;
	constexpr float heightStep = height / (rings - 1);
	constexpr float angleStep = Math::Constants::TwoPi / slices;

	for (int j = 0; j <= slices; ++j)
	{
		mesh.vertices.emplace_back(VertexPN{ { 0.0f, (height * -0.5f), 0.0f }, -Math::Vector3::YAxis });
	}
	for (int i = 0; i < rings; ++i)
	{
		for (int j = 0; j <= slices; ++j)
		{
			float angle = angleStep * j;
			float x = cosf(angle);
			float z = sinf(angle);
			float y = (height * -0.5f) + (heightStep * i);
			mesh.vertices.emplace_back(VertexPN{ { x * radius, y, z * radius }, { x, 0.0f, z } });
		}
	}
	for (int j = 0; j <= slices; ++j)
	{
		mesh.vertices.emplace_back(VertexPN{ { 0.0f, (height * 0.5f), 0.0f }, Math::Vector3::YAxis });
	}
	for (int i = 0; i + 1 < rings + 2; ++i)
	{
		for (int j = 0; j < slices; ++j)
		{
			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 0) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));

			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 0) * (slices + 1)));
		}
	}
	return mesh;
}

MeshPN MeshBuilder::CreateSpherePN(int rings, int slices)
{
	MeshPN mesh;

	const float radius = 1.0f;
	const float thetaStep = Math::Constants::Pi / (rings - 1);
	const float phiStep = Math::Constants::TwoPi / slices;

	for (int i = 0; i < rings; ++i)
	{
		for (int j = 0; j <= slices; ++j)
		{
			float theta = thetaStep * i;
			float phi = phiStep * j;
			float r = sinf(theta);
			float x = cosf(phi) * r;
			float z = sinf(phi) * r;
			float y = -cosf(theta);
			mesh.vertices.emplace_back(VertexPN{ { x * radius, y * radius, z * radius }, { x, y, z } });
		}
	}

	for (int i = 0; i + 1 < rings; ++i)
	{
		for (int j = 0; j < slices; ++j)
		{
			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 0) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));

			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 0) * (slices + 1)));
		}
	}
	return mesh;
}

MeshPX MeshBuilder::CreateSpherePX(float radius, int rings, int slices)
{
	MeshPX mesh;

	const float thetaStep = Math::Constants::Pi / (rings - 1);
	const float phiStep = Math::Constants::TwoPi / slices;
	const float uStep = 1.0f / slices;
	const float vStep = 1.0f / (rings - 1);

	for (int i = 0; i < rings; ++i)
	{
		for (int j = 0; j <= slices; ++j)
		{
			float theta = thetaStep * i;
			float phi = phiStep * j;
			float r = sinf(theta);
			float x = cosf(phi) * r * radius;
			float z = sinf(phi) * r * radius;
			float y = -cosf(theta) * radius;

			Math::Vector3 position = { x, y, z };
			Math::Vector2 uv = { j * uStep, 1.0f - i * vStep };

			mesh.vertices.emplace_back(VertexPX{ position, uv });
		}
	}

	for (int i = 0; i < rings; ++i)
	{
		for (int j = 0; j < slices; ++j)
		{
			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 0) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));

			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 0) * (slices + 1)));
		}
	}
	return mesh;
}

Mesh MeshBuilder::CreateSphere(int rings, int slices)
{
	Mesh mesh;

	const float radius = 1.0f;
	const float thetaStep = Math::Constants::Pi / (rings - 1);
	const float phiStep = Math::Constants::TwoPi / slices;
	const float uStep = 1.0f / slices;
	const float vStep = 1.0f / (rings - 1);

	for (int i = 0; i < rings; ++i)
	{
		for (int j = 0; j <= slices; ++j)
		{
			float theta = thetaStep * i;
			float phi = phiStep * j;
			float r = sinf(theta);
			float x = cosf(phi) * r;
			float z = sinf(phi) * r;
			float y = -cosf(theta);

			Math::Vector3 normal = { x, y, z };
			Math::Vector3 tangent = Math::Normalize({ -z, 0.0f, x });
			Math::Vector2 uv = { j * uStep, 1.0f - i * vStep };

			mesh.vertices.emplace_back(
				Vertex{
					normal * radius,
					normal,
					tangent,
					uv
				});
		}
	}

	for (int i = 0; i < rings; ++i)
	{
		for (int j = 0; j < slices; ++j)
		{
			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 0) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));

			mesh.indices.push_back((j + 0) + ((i + 0) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 1) * (slices + 1)));
			mesh.indices.push_back((j + 1) + ((i + 0) * (slices + 1)));
		}
	}
	return mesh;
}

Mesh PCEngine::Graphics::MeshBuilder::CreatePlane(float size, int rows, int columns)
{
	Mesh mesh;

	const float xStep = size / (rows - 1);
	const float zStep = size / (columns - 1);
	const float uStep = rows / static_cast<float>(rows - 1);
	const float vStep = columns / static_cast<float>(columns - 1);

	Math::Vector3 offset = { size * -0.5f, 0.0f, size * -0.5f };

	for (int z = 0; z < rows; ++z)
	{
		for (int x = 0; x < columns; ++x)
		{
			float xx = xStep * x;
			float zz = zStep * z;
			float y = 0.0f;
			Math::Vector3 position = { xx, 0.0f, zz };
			Math::Vector3 normal = Math::Vector3::YAxis;
			Math::Vector3 tangent = Math::Vector3::XAxis;
			Math::Vector2 uv = { x * uStep, 1.0f - z * vStep };
			mesh.vertices.emplace_back(Vertex{ position + offset, normal, tangent, uv });
		}
	}

	for (int z = 0; z < rows; ++z)
	{
		for (int x = 0; x < columns; ++x)
		{
			mesh.indices.push_back((x + 0) + ((z + 0) * columns));
			mesh.indices.push_back((x + 0) + ((z + 1) * columns));
			mesh.indices.push_back((x + 1) + ((z + 1) * columns));

			mesh.indices.push_back((x + 0) + ((z + 0) * columns));
			mesh.indices.push_back((x + 1) + ((z + 1) * columns));
			mesh.indices.push_back((x + 1) + ((z + 0) * columns));
		}
	}
	return mesh;
}

MeshPX MeshBuilder::CreateNDCQuad()
{
	MeshPX mesh;
	//
	// (-1,+1)---------------(+1,+1)
	//    |          ^          |
	//    |          +->        |
	//    |                     |
	// (-1,-1)---------------(+1,-1)
	//
	mesh.vertices.emplace_back(VertexPX{ {-1.0f, -1.0f, 0.0f }, { 0.0f, 1.0f } });
	mesh.vertices.emplace_back(VertexPX{ {-1.0f, +1.0f, 0.0f }, { 0.0f, 0.0f } });
	mesh.vertices.emplace_back(VertexPX{ {+1.0f, +1.0f, 0.0f }, { 1.0f, 0.0f } });
	mesh.vertices.emplace_back(VertexPX{ {+1.0f, -1.0f, 0.0f }, { 1.0f, 1.0f } });

	mesh.indices.emplace_back(0);
	mesh.indices.emplace_back(1);
	mesh.indices.emplace_back(2);

	mesh.indices.emplace_back(0);
	mesh.indices.emplace_back(2);
	mesh.indices.emplace_back(3);
	return mesh;
}
