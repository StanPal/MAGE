#pragma once

// Engine headers
#include <Core/Inc/Core.h>

// Standard headers
#include <cmath>
#include <numeric>
#include <random>