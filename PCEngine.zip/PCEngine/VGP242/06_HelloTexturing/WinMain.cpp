#include "GameState.h"

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	PCEngine::MainApp().AddState<GameState>("GameState");
	PCEngine::MainApp().Run({ "Hello Texturing", 1280, 720 });
	return 0;
}
