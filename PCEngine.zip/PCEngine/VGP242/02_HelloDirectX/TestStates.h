#pragma once

#include <PCEngine/Inc/PCEngine.h>

class RedState : public PCEngine::AppState
{
public:
	void Initialize() override;
	void Update(float deltaTime) override;
};

class BlueState : public PCEngine::AppState
{
public:
	void Initialize() override;
	void Update(float deltaTime) override;
};