#include "TestStates.h"
#include <PCEngine/Inc/PCEngine.h>

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	PCEngine::MainApp().AddState<RedState>("RedState");
	PCEngine::MainApp().AddState<BlueState>("BlueState");
	PCEngine::MainApp().Run({ "Hello DirectX", 1280, 720 });
	return 0;
}