#include <PCEngine/Inc/PCEngine.h>

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	PCEngine::MainApp().AddState<PCEngine::AppState>("DummyState");
	PCEngine::MainApp().Run({ "Hello Window", 1280, 720 });
	return 0;
}