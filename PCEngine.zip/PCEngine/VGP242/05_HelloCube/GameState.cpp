#include "GameState.h"

using namespace PCEngine::Graphics;
using namespace PCEngine::Input;
using namespace PCEngine::Math;

void GameState::Initialize()
{
	GraphicsSystem::Get()->SetClearColor(Colors::LightGray);

	mCamera.SetPosition({ 0.0f, 0.0f, -5.0f });
	mCamera.SetDirection({ 0.0f, 0.0f, 1.0f });

	mMesh.vertices.emplace_back(VertexPC{ Vector3{ -0.5f, -0.5f, -0.5f }, Colors::Orange });
	mMesh.vertices.emplace_back(VertexPC{ Vector3{ -0.5f,  0.5f, -0.5f }, Colors::Cyan });
	mMesh.vertices.emplace_back(VertexPC{ Vector3{  0.5f,  0.5f, -0.5f }, Colors::DarkMagenta });
	mMesh.vertices.emplace_back(VertexPC{ Vector3{  0.5f, -0.5f, -0.5f }, Colors::SlateBlue });

	mMesh.vertices.emplace_back(VertexPC{ Vector3{ -0.5f, -0.5f,  0.5f }, Colors::LightGreen });
	mMesh.vertices.emplace_back(VertexPC{ Vector3{ -0.5f,  0.5f,  0.5f }, Colors::Cornsilk });
	mMesh.vertices.emplace_back(VertexPC{ Vector3{  0.5f,  0.5f,  0.5f }, Colors::PaleVioletRed });
	mMesh.vertices.emplace_back(VertexPC{ Vector3{  0.5f, -0.5f,  0.5f }, Colors::ForestGreen });

	// Front
	mMesh.indices.push_back(0);
	mMesh.indices.push_back(1);
	mMesh.indices.push_back(2);

	mMesh.indices.push_back(0);
	mMesh.indices.push_back(2);
	mMesh.indices.push_back(3);

	// Right
	mMesh.indices.push_back(3);
	mMesh.indices.push_back(2);
	mMesh.indices.push_back(6);

	mMesh.indices.push_back(3);
	mMesh.indices.push_back(6);
	mMesh.indices.push_back(7);

	// Back
	mMesh.indices.push_back(7);
	mMesh.indices.push_back(6);
	mMesh.indices.push_back(5);

	mMesh.indices.push_back(7);
	mMesh.indices.push_back(5);
	mMesh.indices.push_back(4);

	// Left
	mMesh.indices.push_back(4);
	mMesh.indices.push_back(5);
	mMesh.indices.push_back(1);

	mMesh.indices.push_back(4);
	mMesh.indices.push_back(1);
	mMesh.indices.push_back(0);

	// Top
	mMesh.indices.push_back(1);
	mMesh.indices.push_back(5);
	mMesh.indices.push_back(6);

	mMesh.indices.push_back(1);
	mMesh.indices.push_back(6);
	mMesh.indices.push_back(2);

	// Bottom
	mMesh.indices.push_back(4);
	mMesh.indices.push_back(0);
	mMesh.indices.push_back(3);

	mMesh.indices.push_back(4);
	mMesh.indices.push_back(3);
	mMesh.indices.push_back(7);

	mMeshBuffer.Initialize(mMesh);

	mConstantBuffer.Initialize(sizeof(Matrix4));

	mVertexShader.Initialize("../../Assets/Shaders/DoTransform.fx", VertexPC::Format);
	mPixelShader.Initialize("../../Assets/Shaders/DoTransform.fx");
}

void GameState::Terminate()
{
	mPixelShader.Terminate();
	mVertexShader.Terminate();
	mConstantBuffer.Terminate();
	mMeshBuffer.Terminate();
}

void GameState::Update(float deltaTime)
{
	const float kMoveSpeed = 10.0f;
	const float kTurnSpeed = 1.0f;

	auto inputSystem = InputSystem::Get();
	if (inputSystem->IsKeyDown(KeyCode::W))
		mCamera.Walk(kMoveSpeed * deltaTime);
	if (inputSystem->IsKeyDown(KeyCode::S))
		mCamera.Walk(-kMoveSpeed * deltaTime);
	mCamera.Yaw(inputSystem->GetMouseMoveX() * kTurnSpeed * deltaTime);
	mCamera.Pitch(inputSystem->GetMouseMoveY() * kTurnSpeed * deltaTime);

	if (inputSystem->IsKeyDown(KeyCode::UP))
		mRotation.x += deltaTime;
	if (inputSystem->IsKeyDown(KeyCode::DOWN))
		mRotation.x -= deltaTime;
	if (inputSystem->IsKeyDown(KeyCode::LEFT))
		mRotation.y += deltaTime;
	if (inputSystem->IsKeyDown(KeyCode::RIGHT))
		mRotation.y -= deltaTime;
}

void GameState::Render()
{
	auto context = GraphicsSystem::Get()->GetContext();

	auto matRot = Matrix4::RotationX(mRotation.x) * Matrix4::RotationY(mRotation.y);
	auto matView = mCamera.GetViewMatrix();
	auto matProj = mCamera.GetPerspectiveMatrix();
	mConstantBuffer.BindVS();

	mVertexShader.Bind();
	mPixelShader.Bind();

	const float spacing = 1.8f;
	for (int y = -1; y <= 1; ++y)
	{
		for (float x = -1; x <= 1; ++x)
		{
			auto matTrans = Matrix4::Translation({ x * spacing, y * spacing, 0.0f });
			auto matWVP = Transpose(matRot * matTrans * matView * matProj);
			mConstantBuffer.Update(&matWVP);
			mMeshBuffer.Draw();
		}
	}
}
